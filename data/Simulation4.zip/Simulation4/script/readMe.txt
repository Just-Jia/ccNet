synthetic/dyntoy/multifurcating_7.rds at https://doi.org/10.5281/zenodo.1443566
celltypes: 'M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M8', 'M9'
labels: 1,2,3,4,5,6,7,8,9
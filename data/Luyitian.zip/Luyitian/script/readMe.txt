real/gold/cellbench-SC4_luyitian.rds at https://doi.org/10.5281/zenodo.1443566
celltype: 'H2228', 'H1975', 'H1975,H2228,HCC827', 'HCC827'
labels: 1, 2, 3, 4
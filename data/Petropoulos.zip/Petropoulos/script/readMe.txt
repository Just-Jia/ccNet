
celltype: 'embryonic day 3', 'embryonic day 4', 'embryonic day 5', 'embryonic day 6', 'embryonic day 7'
labels: 1,2,3,4,5
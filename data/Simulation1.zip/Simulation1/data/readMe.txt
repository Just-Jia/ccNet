'synthetic/dyntoy/multifurcating_5.rds' at 'https://doi.org/10.5281/zenodo.1443566'
celltype: 'M1', 'M2', 'M3', 'M4'
labels: 1,2,3,4